import re

re_if = re.compile(r'#if\s+(?P<condition>.+)')
re_ifdef = re.compile(r'#ifdef\s+(?P<condition>.+)')
re_ifndef = re.compile(r'#ifndef\s+(?P<condition>.+)')
re_undef = re.compile(r'#undef\s+(?P<object>.+)')
re_define2 = re.compile(r'#define\s+(?P<object1>.+)\s+(?P<object2>.+)')
re_define1 = re.compile(r'#define\s+(?P<object>.+)')
re_else = re.compile(r'#else\s*')
re_endif = re.compile(r'#endif\s*')
re_error = re.compile(r'#error\s+\"(?P<message>.*)\"')

re_arr = [
    re_if,
    re_ifdef,
    re_ifndef,
    re_undef,
    re_define2,
    re_define1,
    re_else,
    re_endif,
    re_error,
]

f = open('vm.c', 'r')
stack = []
pcode = ''
tab_level = 0
def tab(level):
    return (tab_level * 4) * ' '

for line in f:
    line = line.strip()
    found = False
    for pattern in re_arr:
        res = pattern.match(line)
        if res:
            found = True
            if pattern == re_if:
                condition = res.group('condition')
                pcode += tab(tab_level) + f'if ( {condition} )\n'
                pcode += tab(tab_level) +  '{\n'
                tab_level += 1
                stack.append(1)
                pass
            elif pattern == re_ifdef:
                condition = res.group('condition')
                pcode += tab(tab_level) + f'if ( {condition} == 1 )\n'
                pcode += tab(tab_level) +  '{\n'
                tab_level += 1
                stack.append(1)
                pass
            elif pattern == re_ifndef:
                condition = res.group('condition')
                pcode += tab(tab_level) + f'if ( {condition} == 0 )\n'
                pcode += tab(tab_level) +  '{\n'
                tab_level += 1
                stack.append(1)
                pass
            elif pattern == re_undef:
                obj = res.group('object')
                pcode += tab(tab_level) + f'{obj} = 0;\n'
                pass
            elif pattern == re_define2:
                obj1 = res.group('object1')
                obj2 = res.group('object2')
                pcode += tab(tab_level) + f'{obj1} = {obj2};\n'
                pass
            elif pattern == re_define1:
                obj = res.group('object')
                pcode += tab(tab_level) + f'{obj} = 1;\n'
                pass
            elif pattern == re_else:
                tab_level -= 1
                pcode += tab(tab_level) + '}\n'
                pcode += tab(tab_level) + 'else\n'
                pcode += tab(tab_level) + '{\n'
                tab_level += 1
                pass
            elif pattern == re_endif:
                tab_level -= 1
                stack.pop()
                pcode += tab(tab_level) + '}\n'
                pass
            elif pattern == re_error:
                message = res.group('message')
                pcode += tab(tab_level) + f'exit({message});\n'
                pass
            else:
                assert (False)
            break
    if not found:
        print (line)
        assert False
f.close()
print (pcode)