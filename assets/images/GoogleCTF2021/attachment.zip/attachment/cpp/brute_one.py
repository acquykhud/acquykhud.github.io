import subprocess
chars = 'CTF{_}abcdefghijklmnopqrstuvwxyzABCDEGHIJKLMNOPQRSUVWXYZ0123456789'
import sys

result = ''

def get_src(pos: int, val: int):
    global result
    data = b''
    with open('template.c', 'rb') as f:
        data = f.read()
    s = b'VARVAR_%02d' % pos
    data = data.replace(s, str(val).encode())
    i = 0
    while i < len(result):
        z = result[i]
        s = b'VARVAR_%02d' % i
        data = data.replace(s, str(ord(z)).encode())
        i += 1
    while i < 27:
        s = b'VARVAR_%02d' % i
        data = data.replace(s, b'65')
        i += 1
    with open('cpp.c', 'wb') as f:
        f.write(data)

def brute(pos):
    global result
    for c in chars:
        print (f'Trying {c} at {pos}',  file=sys.stderr, flush=True)
        get_src(pos, ord(c))
        ps = subprocess.Popen(['gcc', 'cpp.c', '-fno-diagnostics-color'], stderr=subprocess.PIPE)
        output = subprocess.check_output(('grep', '--color=never', '#pragma message: My Value  ='), stdin=ps.stderr)
        ps.wait()
        output = [i.replace(b'\xe2\x80\x99', b'').replace(b'\xe2\x80\x98', b'').decode() for i in output.split(b'\n') if len(i) > 0]
        care = output[pos].replace('cpp.c:5919:9: note: #pragma message: My Value  = ', '').replace('cpp.c:5919: note: #pragma message: My Value  = ', '')
        if care == 'A7A6A5A4A3A2A1A0':
            result += c
            return c
    assert False

print(result, end='', flush=True)
for i in range(len(result), 27):
    c = brute(i)
    print (c, end='', flush=True)
print('')