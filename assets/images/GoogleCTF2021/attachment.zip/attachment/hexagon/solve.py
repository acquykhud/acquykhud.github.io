def MyNot(x):
    return x ^ 0xFFFFFFFF

def Minus(x):
    return 4294967296 - x

def tstbit(x,y):
    return (x & (1 << y)) != 0

from z3 import *
r0,r1,r2,r3,r4,r5 = 0,0,0,0,0,0

X = BitVec('x', 32)
Y = BitVec('y', 32)

r2, r3 = X, Y
r0 = 0x6F67202A
r0, r2 = r2, r0
r1 = 1
def hex1():
    global r0
    global r1
    global r2
    global r3
    global r4
    global r5
    if tstbit(r1, 6):
        r5 = 0x7A024204
        r0 = (r0 + r5) & 0xFFFFFFFF
        r0 = MyNot(r0)
    else:
        r5 = 0xA5D2F34
        r0 = (r0 + r5) & 0xFFFFFFFF
        r0 = MyNot(r0)
hex1()

r2 = r2 ^ r0
r0 = 0x656C676F
r0, r3 = r3, r0
r1 = 6

def hex2():
    global r0
    global r1
    global r2
    global r3
    global r4
    global r5
    if tstbit(r1, 3):
        r5 = Minus(0x190BA6F5)
        r0 ^= r5
        r5 = 0x5487CE1E
        r0 = (r0 + r5) & 0xFFFFFFFF
    else:
        r0 = MyNot(r0)
        r5 = 0x48268673
        r0 ^= r5
hex2()

r3 ^= r0
r0 = 0x6E696220
r1 = 0xF

def hex3():
    global r0
    global r1
    global r2
    global r3
    global r4
    global r5
    if tstbit(r1, 8):
        r0 = MyNot(r0)
        r5 = Minus(0x7A889166)
        r0 = (r0 + r5) & 0xFFFFFFFF
    else:
        r5 = 0x5A921187
        r0 ^= r5
        r5 = Minus(0x1644E844)
        r0 = (r0 + r5) & 0xFFFFFFFF

hex3()
r0 ^= r3
r2, r3 = r3, r2 ^ r0
r0 = 0x682D616A
r1 = 0x1C
def hex4():
    global r0
    global r1
    global r2
    global r3
    global r4
    global r5
    if tstbit(r1, 0):
        r0 = MyNot(r0)
        r0 = MyNot(r0)
    else:
        r0 = MyNot(r0)
        r5 = Minus(0x28EFC82F)
        r0 ^= r5
hex4()

r0 ^= r3
r2, r3 = r3, r2 ^ r0
r0 = 0x67617865
r1 = 0x2D

def hex5():
    global r0
    global r1
    global r2
    global r3
    global r4
    global r5
    if tstbit(r1, 0):
        r0 = MyNot(r0)
        r5 = 0x101FBCCC
        r0 = (r0 + r5) & 0xFFFFFFFF
    else:
        r0 = MyNot(r0)
        r5 = 0x55485822
        r0 = (r0 + r5) & 0xFFFFFFFF
hex5()

r0 ^= r3
r2, r3 = r3, r2 ^ r0
r0 = 0x2A206E6F
r1 = 0x42

def hex6():
    global r0
    global r1
    global r2
    global r3
    global r4
    global r5
    if tstbit(r1, 3):
        r5 = 0x49A3E80E
        r0 ^= r5
        r5 = 0x6288E1A5
        r0 ^= r5
    else:
        r5 = Minus(0x74FE9C3F)
        r0 ^= r5
        r5 = Minus(0x1131CD75)
        r0 ^= r5
hex6()

r0 ^= r3
r2, r3 = r3, r2 ^ r0

s = Solver()
s.add(r2 == 1837154199)
s.add(r3 == 2638548541)
assert (s.check() == sat)
m  = s.model()
x = m[X].as_long()
y = m[Y].as_long()
print ((b'CTF{' + (x + (y << 32)).to_bytes(8, 'little') + b'}').decode())