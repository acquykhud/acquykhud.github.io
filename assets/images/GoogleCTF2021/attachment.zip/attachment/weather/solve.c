#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int g[5] = {0};
const int prime[] = {13217, 13219, 13229, 13241, 13249, 13259, 13267, 13291, 13297, 13309, 13313, 13327, 13331, 13337, 13339, 13367, 13381, 13397, 13399, 13411, 13417, 13421, 13441, 13451, 13457, 13463, 13469, 13477, 13487, 13499, 13513, 13523, 13537, 13553, 13567, 13577, 13591, 13597};
void GenRandom();

void Func12()
{
    g[1] = g[0] % 2;
    if (g[1] == 0)
        g[0] /= 2;
    if (g[1] > 0)
        g[0] = g[0] * 3 + 1;
    GenRandom();
    g[0]++;
}

void GenRandom()
{
    g[1] = g[0] - 1;
    if (g[1] == 0)
        g[0] = 0;
    if (g[1] > 0)
        Func12();
}

int main()
{
    int e[7] = {
        1374542625 + 1686915720 + 1129686860,
        842217029 + 1483902564,
        1868013731,
        584694732 + 1453312700,
        223548744,
        1958883726 + 1916008099,
        1829937605 + 1815356086 + 253836698,
    };
    unsigned char key2[28] = {0};
    for (int i = 1; i <= 28; ++i)
    {
        g[0] = i;
        GenRandom();
        key2[i - 1] = (g[0] & 0xFF);
    }
    unsigned char* enc = (unsigned char*)&e[0];
    unsigned char* key = (unsigned char*)&prime[0];
    for (int i = 0; i < 28; ++i) 
    {
        unsigned char tmp = (enc[i] - key2[i]) ^ key[i*4];
        printf("%c", tmp);
    }
    puts("");
    return 0;
}