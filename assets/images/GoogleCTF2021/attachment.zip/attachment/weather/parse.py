from struct import unpack
import re

re_pattern = re.compile(r'(?P<sign>[-+])?(?P<width>[0123456789]+)(\.(?P<prec>[0-9]+))?(?P<length>(h|hh|ll|q|l))?(?P<identifier>[MSOXVNLREIUC])')

g_data = b''
with open('data.bin', 'rb') as f:
    g_data = f.read()

def u32(x):
    return unpack('<I', x)[0]

def get_str(ea, data=None, maximum=1000):
    if data is None:
        data = g_data
    r = b''
    i = 0
    while i < maximum:
        c = data[ea+i:ea+i+1]
        if c == b'\x00':
            break
        r = r + c
        i += 1
    return r.decode()

def decompile(x, data=None):
    if data is None:
        data = bytes([i for i in g_data])
    arr = [i for i in x.split('%') if len(i) > 0]
    r = f'[+] Decompile for "{x}"\n'
    for idx in range(len(arr)):
        s = arr[idx]
        match = re_pattern.match(s)
        if not match:
            assert False, s
        sign = match.group('sign')
        width = match.group('width')
        prec = match.group('prec')
        length = match.group('length')
        identifier = match.group('identifier')

        is_char = (length == 'hh')
        is_short = (length == 'h')
        is_long = (length == 'l')
        is_long_double = (length == 'll' or length == 'q')
        pad = '0' if width.startswith('0') else ' '

        r += '%-10s: ' % s
        if identifier != 'C':
            lhs, rsh = '', ''
            if sign == '-':
                lhs = f'*(DWORD*)(as52c + {width})'
            elif sign == '+':
                lhs = f'*(DWORD*)(as52c + g_arr[{width}])'
            elif sign is None:
                lhs = f'g_arr[{width}]'
            else:
                assert False, 'Sign: ' + sign
            
            if is_char:
                rhs = f'*(DWORD*)(as52c + {prec}) = {u32(data[int(prec):int(prec)+4])}'
            elif is_short:
                rhs = f'*(DWORD*)(as52c + g_arr[{prec}])'
            elif is_long:
                rhs = f'g_arr[{prec}]'
            elif is_long_double:
                rhs = f'{prec}'
            else:
                assert False, 'is_XXX'

            assert len(lhs) > 0
            assert len(rhs) > 0

            

            if identifier == 'M':
                r += lhs + ' = ' + rhs
            elif identifier == 'S':
                r += lhs + ' += ' + rhs
            elif identifier == 'O':
                r += lhs + ' -= ' + rhs
            elif identifier == 'X':
                r += lhs + ' *= ' + rhs
            elif identifier == 'V':
                r += lhs + ' /= ' + rhs
            elif identifier == 'N':
                r += lhs + ' %= ' + rhs
            elif identifier == 'L':
                r += lhs + ' <<= ' + rhs
            elif identifier == 'R':
                r += lhs + ' >>= ' + rhs
            elif identifier == 'E':
                r += lhs + ' ^= ' + rhs
            elif identifier == 'I':
                r += lhs + ' &= ' + rhs
            elif identifier == 'U':
                r += lhs + ' |= ' + rhs
            else:
                assert False
            
        elif identifier == 'C':
            if sign == '-':
                r += f'flag = g_arr[{prec}] < 0'
            elif sign == '+':
                r += f'flag = g_arr[{prec}] > 0'
            elif pad == '0':
                r += f'flag = g_arr[{prec}] == 0'
            else:
                r += 'flag = True'
            r += '\n'+ ' ' * 12
            r += 'if (flag):\n' + ' ' * 16
            r += 'fprintf "' + get_str(int(width), data) + '"'
        else:
            assert False, 'Identifier: ' + identifier
        if idx != len(arr) - 1:
            r += '\n'
    return r
        
print ('-' * 100)
print (decompile(r'%3.1hM%3.0lE%+1.3lM%1.4llS%3.1lM%3.2lO%-7.3C'))
print ('-' * 100)
print (decompile(r'%0.4096hhM%0.255llI%1.0lM%1.8llL%0.1lU%1.0lM%1.16llL%0.1lU%1.200llM%2.1788llM%7C%-6144.1701736302llM%0.200hhM%0.255llI%0.37llO%0200.0C'))
print ('-' * 100)

cdata = bytearray(g_data[200:1788])
for i in range(len(cdata)):
   cdata[i] ^= ord('T')
cdata = g_data[0:200] + bytes(cdata) + g_data[1788:]
with open('newdata.bin', 'wb') as f:
    f.write(cdata)

print(decompile(r'%4.5000llM%0.13200llM%337C%0.0llM%500C%1262C%0653.0C', cdata))
print ('-' * 100)
print(decompile(r'%1.0llM', cdata))
print ('-' * 100)
print(decompile(r'%3.0lM%3.2lN%0253.3C%2.1llS%3.2lM%3.3lX%3.0lO%3.1llO%-261.3C', cdata))
print ('-' * 100)
print(decompile(r'%+4.0lM%4.2llS', cdata))
print ('-' * 100)
print(decompile(r'%1.1llM%2.2llM%261C%+322.1C%0.1llS%1.13600llM%1.0lO%+337.1C', cdata))
print ('-' * 100)
print(decompile(r'%0.0llM', cdata))
print ('-' * 100)
print(decompile(r'%0.2llV', cdata))
print ('-' * 100)
print(decompile(r'%0.3llX%0.1llS', cdata))
print ('-' * 100)
print(decompile(r'%1.0lM%1.2llN%0405.1C%+413.1C%470C%0.1llS', cdata))
print ('-' * 100)
print(decompile(r'%1.0lM%1.1llO%0397.1C%+428.1C', cdata))
print ('-' * 100)
print(decompile(r'%2.0lM%2.4096llS%4.2hM%4.255llI%+540.4C', cdata))
print ('-' * 100)
print(decompile(r'%2.0lM%2.2llX%2.5000llS%2.2hM%2.255llI%4.2lE%0.1llS%2.0lM%470C%4.0lS%4.255llI%0.2lM%2.1llO%2.4500llS%+2.4lM%500C', cdata))
print ('-' * 100)
print(decompile(r'%0.123456789llM%1.0llM%1.4096llS%1.1hM%0.1lE%2.0llM%2.846786818llS%2.0lE%1.0llM%1.6144llS%+1.2lM%1.4llM%1.4096llS%1.1hM%0.1lE%2.0llM%2.1443538759llS%2.0lE%1.4llM%1.6144llS%+1.2lM%1.8llM%1.4096llS%1.1hM%0.1lE%2.0llM%2.1047515510llS%2.0lE%1.8llM%1.6144llS%+1.2lM%1.12llM%1.4096llS%1.1hM%0.1lE%2.0llM%2.359499514llS%2.1724461856llS%2.0lE%1.12llM%1.6144llS%+1.2lM%1.16llM%1.4096llS%1.1hM%0.1lE%2.0llM%2.241024035llS%2.0lE%1.16llM%1.6144llS%+1.2lM%1.20llM%1.4096llS%1.1hM%0.1lE%2.0llM%2.222267724llS%2.0lE%1.20llM%1.6144llS%+1.2lM%1.24llM%1.4096llS%1.1hM%0.1lE%2.0llM%2.844096018llS%2.0lE%1.24llM%1.6144llS%+1.2lM', cdata))
print ('-' * 100)
print(decompile(r'%0.0llM%1.0llM%1.4500llS%1.1hM%2.0llM%2.1374542625llS%2.1686915720llS%2.1129686860llS%1.2lE%0.1lU%1.4llM%1.4500llS%1.1hM%2.0llM%2.842217029llS%2.1483902564llS%1.2lE%0.1lU%1.8llM%1.4500llS%1.1hM%2.0llM%2.1868013731llS%1.2lE%0.1lU%1.12llM%1.4500llS%1.1hM%2.0llM%2.584694732llS%2.1453312700llS%1.2lE%0.1lU%1.16llM%1.4500llS%1.1hM%2.0llM%2.223548744llS%1.2lE%0.1lU%1.20llM%1.4500llS%1.1hM%2.0llM%2.1958883726llS%2.1916008099llS%1.2lE%0.1lU%1.24llM%1.4500llS%1.1hM%2.0llM%2.1829937605llS%2.1815356086llS%2.253836698llS%1.2lE%0.1lU', cdata))
print ('-' * 100)

